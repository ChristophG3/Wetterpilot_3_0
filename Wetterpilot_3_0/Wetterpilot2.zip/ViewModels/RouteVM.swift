import Foundation
import SwiftUI

@MainActor
final class RouteVM: ObservableObject {
    @Published var startDate: Date
    @Published var durationDays: Int
    @Published var places: [String]
    @Published var weights: Weights
    @Published var summary: [SummaryItem] = []
    @Published var detailsByDate: [String: [DetailItem]] = [:] // yyyy-MM-dd -> day details
    
    let deps: AppDependencies
    
    var hasSeenWelcome: Bool {
        get { deps.store.hasSeenWelcome }
        set { deps.store.hasSeenWelcome = newValue }
    }
    
    init(deps: AppDependencies) {
        self.deps = deps
        self.startDate = deps.store.startDate ?? Date()
        self.durationDays = max(1, min(10, deps.store.durationDays))
        let persisted = deps.store.places
        if persisted.isEmpty {
            self.places = Array(repeating: "", count: self.durationDays)
        } else {
            self.places = persisted
            self.places = Array(self.places.prefix(self.durationDays)) + Array(repeating: "", count: max(0, self.durationDays - self.places.count))
        }
        self.weights = deps.store.weights
    }
    
    func setHasSeenWelcome() { hasSeenWelcome = true }
    
    func updateDuration(_ newVal: Int) {
        durationDays = max(1, min(10, newVal))
        if places.count < durationDays {
            places += Array(repeating: "", count: durationDays - places.count)
        } else if places.count > durationDays {
            places = Array(places.prefix(durationDays))
        }
        deps.store.durationDays = durationDays
        deps.store.places = places
    }
    
    func updatePlace(_ idx: Int, _ name: String) {
        guard idx >= 0 && idx < places.count else { return }
        places[idx] = name
        deps.store.places = places
    }
    
    func resetAll() {
        deps.store.resetAll()
        startDate = Date()
        durationDays = 3
        places = Array(repeating: "", count: durationDays)
        weights = Weights()
        summary = []
        detailsByDate = [:]
    }
    
    var minStart: Date { Date() }
    var maxStart: Date {
        let days = 10 - (durationDays - 1) // 10-day horizon
        return Calendar.current.date(byAdding: .day, value: max(0, days), to: Date()) ?? Date()
    }
    
    struct SummaryItem: Identifiable {
        let id = UUID()
        let key: String // yyyy-MM-dd
        let score: Int
        let rainyDays: Int
        let avgTemp: Double
        let sunHours: Double
        let avgWind: Double
    }
    struct DetailItem: Identifiable {
        let id = UUID()
        let dateISO: String
        let placeName: String
        let emoji: String
        let tRange: String
        let rain: String
        let sun: String
        let wind: String
    }
    
    func analyze() async {
        // Validate non-empty places
        guard places.filter({ !$0.trimmingCharacters(in: .whitespaces).isEmpty }).count == durationDays else {
            return
        }
        
        deps.store.startDate = startDate
        deps.store.weights = weights
        
        // Geocode all places
        var geo: [GeoPlace] = []
        do {
            for name in places {
                let g = try await deps.geocoding.geocode(name)
                geo.append(g)
            }
        } catch {
            print("Geocoding error: \(error)")
            return
        }
        
        // Fetch forecasts for each place
        var forecasts: [[ForecastDay]] = []
        do {
            for g in geo {
                var arr = try await deps.weather.fetchDaily(lat: g.latitude, lon: g.longitude)
                // stamp with place id
                arr = arr.map { d in
                    var m = d
                    m = ForecastDay(placeID: g.id, dateISO: d.dateISO, tMin: d.tMin, tMax: d.tMax, rainMM: d.rainMM, sunHours: d.sunHours, windKmh: d.windKmh, weatherCode: d.weatherCode)
                    return m
                }
                forecasts.append(arr)
            }
        } catch {
            print("Forecast error: \(error)")
            return
        }
        
        // Build a date → [ForecastDay] map per date
        var byDate: [String: [ForecastDay]] = [:]
        for placeArr in forecasts {
            for d in placeArr {
                byDate[d.dateISO, default: []].append(d)
            }
        }
        
        // Candidate start keys within [minStart ... maxStart]
        var items: [SummaryItem] = []
        var details: [String: [DetailItem]] = [:]
        
        let df = ISO8601DateFormatter.dateOnly
        var start = max(startDate, minStart)
        let end = maxStart
        let cal = Calendar.current
        
        while start <= end {
            var daysForScore: [ForecastDay] = []
            var detailItems: [DetailItem] = []
            var rainyCount = 0
            var tempSum = 0.0
            var windSum = 0.0
            var sunSum = 0.0
            
            for i in 0..<durationDays {
                guard let d = cal.date(byAdding: .day, value: i, to: start) else { continue }
                let key = df.string(from: d)
                // pick forecast for the given day's place index
                let placeID = geo[i].id
                if let match = byDate[key]?.first(where: { $0.placeID == placeID }) {
                    daysForScore.append(match)
                    if match.rainMM >= 1 { rainyCount += 1 }
                    tempSum += (match.tMin + match.tMax) / 2.0
                    windSum += match.windKmh
                    sunSum  += match.sunHours
                    
                    let det = DetailItem(dateISO: key,
                                         placeName: geo[i].name,
                                         emoji: WeatherEmoji.emoji(for: match.weatherCode),
                                         tRange: String(format: "%.0f–%.0f°C", match.tMin, match.tMax),
                                         rain: String(format: "%.1f mm", match.rainMM),
                                         sun: String(format: "%.1f h", match.sunHours),
                                         wind: String(format: "%.0f km/h", match.windKmh))
                    detailItems.append(det)
                }
            }
            
            if daysForScore.count == durationDays {
                let bd = StandardScoring.score(days: daysForScore, weights: weights)
                let avgTemp = tempSum / Double(durationDays)
                let avgWind = windSum / Double(durationDays)
                let item = SummaryItem(key: df.string(from: start), score: bd.total, rainyDays: rainyCount, avgTemp: avgTemp, sunHours: sunSum, avgWind: avgWind)
                items.append(item)
                details[item.key] = detailItems
            }
            guard let next = cal.date(byAdding: .day, value: 1, to: start) else { break }
            start = next
        }
        
        // sort by date; also highlight best (handled in UI)
        summary = items.sorted { $0.key < $1.key }
        detailsByDate = details
    }
}
