import Foundation

protocol GeocodingProvider {
    func geocode(_ name: String) async throws -> GeoPlace
}

final class OpenMeteoGeocodingProvider: GeocodingProvider {
    private let network: NetworkClient
    private let caches: Caches
    private let ttl: TimeInterval = 60 * 60 * 24
    
    init(network: NetworkClient, caches: Caches) {
        self.network = network
        self.caches = caches
    }
    
    func geocode(_ name: String) async throws -> GeoPlace {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let key = "geocode_\(trimmed.lowercased())"
        if let d = caches.memory.get(key) ?? caches.disk.get(key) {
            if let g = try? JSONDecoder().decode(GeoPlace.self, from: d) { return g }
        }
        var comps = URLComponents(string: "https://geocoding-api.open-meteo.com/v1/search")!
        comps.queryItems = [
            .init(name: "name", value: trimmed),
            .init(name: "count", value: "1")
        ]
        guard let url = comps.url else { throw NetworkClient.NetError.badURL }
        let data = try await network.get(url: url)
        struct R: Codable {
            struct Res: Codable { let name: String; let latitude: Double; let longitude: Double }
            let results: [Res]?
        }
        let r = try JSONDecoder().decode(R.self, from: data)
        guard let first = r.results?.first else {
            throw NSError(domain: "Geocoding", code: 0, userInfo: [NSLocalizedDescriptionKey: "Place not found"])
        }
        let gp = GeoPlace(name: first.name, latitude: first.latitude, longitude: first.longitude)
        if let enc = try? JSONEncoder().encode(gp) {
            caches.memory.set(key, data: enc, ttl: ttl)
            caches.disk.set(key, data: enc, ttl: ttl)
        }
        return gp
    }
}
