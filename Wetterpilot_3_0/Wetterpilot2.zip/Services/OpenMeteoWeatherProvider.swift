import Foundation
import CoreLocation

protocol WeatherProvider {
    func fetchDaily(lat: Double, lon: Double) async throws -> [ForecastDay]
}

final class OpenMeteoWeatherProvider: WeatherProvider {
    private let network: NetworkClient
    private let caches: Caches
    private let ttl: TimeInterval = 60 * 60 * 24 // 24h
    
    init(network: NetworkClient, caches: Caches) {
        self.network = network
        self.caches = caches
    }
    
    func fetchDaily(lat: Double, lon: Double) async throws -> [ForecastDay] {
        let key = "forecast_\(String(format: "%.3f_%.3f", lat, lon))"
        if let d = caches.memory.get(key) ?? caches.disk.get(key) {
            if let arr = try? JSONDecoder().decode([ForecastDay].self, from: d) { return arr }
        }
        
        // Request daily forecast (10-day horizon typical)
        // sunshine_duration is seconds → convert to hours
        var comps = URLComponents(string: "https://api.open-meteo.com/v1/forecast")!
        comps.queryItems = [
            .init(name: "latitude", value: String(lat)),
            .init(name: "longitude", value: String(lon)),
            .init(name: "daily", value: "weathercode,temperature_2m_max,temperature_2m_min,precipitation_sum,windspeed_10m_max,sunshine_duration"),
            .init(name: "timezone", value: "auto")
        ]
        guard let url = comps.url else { throw NetworkClient.NetError.badURL }
        
        let data = try await network.get(url: url)
        struct R: Codable {
            struct Daily: Codable {
                let time: [String]
                let weathercode: [Int]
                let temperature_2m_min: [Double]
                let temperature_2m_max: [Double]
                let precipitation_sum: [Double]
                let windspeed_10m_max: [Double]
                let sunshine_duration: [Double]?
            }
            let daily: Daily
        }
        let r = try JSONDecoder().decode(R.self, from: data)
        var out: [ForecastDay] = []
        for i in 0..<r.daily.time.count {
            let sunH = (r.daily.sunshine_duration?[i] ?? 0.0) / 3600.0
            let fd = ForecastDay(placeID: "", dateISO: r.daily.time[i],
                                 tMin: r.daily.temperature_2m_min[i],
                                 tMax: r.daily.temperature_2m_max[i],
                                 rainMM: r.daily.precipitation_sum[i],
                                 sunHours: sunH,
                                 windKmh: r.daily.windspeed_10m_max[i],
                                 weatherCode: r.daily.weathercode[i])
            out.append(fd)
        }
        
        if let enc = try? JSONEncoder().encode(out) {
            caches.memory.set(key, data: enc, ttl: ttl)
            caches.disk.set(key, data: enc, ttl: ttl)
        }
        return out
    }
}
