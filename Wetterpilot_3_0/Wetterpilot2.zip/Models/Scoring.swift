import Foundation

struct Weights: Codable, Equatable {
    var rain: Int = 2   // 0...3
    var wind: Int = 1
    var heat: Int = 1
    var cold: Int = 1
    var sun: Int = 2
}

struct ScoreBreakdown {
    let total: Int
    let rainPenalty: Double
    let windPenalty: Double
    let heatPenalty: Double
    let coldPenalty: Double
    let sunBonus: Double
}

enum StandardScoring {
    static func score(days: [ForecastDay], weights: Weights) -> ScoreBreakdown {
        var base: Double = 100
        
        var rainP = 0.0, windP = 0.0, heatP = 0.0, coldP = 0.0, sunB = 0.0
        
        for day in days {
            rainP += Double(weights.rain) * min(day.rainMM, 30)
            windP += Double(weights.wind) * max(0, day.windKmh - 25)
            heatP += Double(weights.heat) * max(0, day.tMax - 28)
            coldP += Double(weights.cold) * max(0, 10 - day.tMin)
            sunB  += Double(weights.sun)  * min(day.sunHours, 12) * 0.5
        }
        
        let total = max(0, min(100, Int((base - (rainP + windP + heatP + coldP) + sunB).rounded())))
        return .init(total: total, rainPenalty: rainP, windPenalty: windP, heatPenalty: heatP, coldPenalty: coldP, sunBonus: sunB)
    }
}
