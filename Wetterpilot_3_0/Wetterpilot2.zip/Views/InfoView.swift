import SwiftUI

struct InfoView: View {
    var body: some View {
        NavigationStack {
            List {
                Section("Wetterpilot 2.0") {
                    Text("Wetterplanung für Fahrradtouren.")
                }
                Section("Rechtliches") {
                    Text("Impressum & Datenschutz – bitte in der App ergänzen.")
                }
            }
            .navigationTitle(Text(NSLocalizedString("menu_info", comment: "")))
        }
    }
}
