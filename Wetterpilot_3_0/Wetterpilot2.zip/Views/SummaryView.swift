import SwiftUI

struct SummaryView: View {
    @EnvironmentObject var vm: RouteVM
    @State private var selectedKey: String?
    @State private var showShare = false
    @State private var pdfURL: URL?
    
    var body: some View {
        List {
            if let best = vm.summary.max(by: { $0.score < $1.score }) {
                Section(header: Text("Empfehlung")) {
                    SummaryRow(item: best).onTapGesture { selectedKey = best.key }
                }
            }
            Section(header: Text(NSLocalizedString("start_settings", comment: ""))) {
                ForEach(vm.summary) { item in
                    SummaryRow(item: item).onTapGesture { selectedKey = item.key }
                }
            }
        }
        .navigationTitle(NSLocalizedString("start_settings", comment: ""))
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                Button {
                    if let url = vm.deps.pdf.exportSummary(items: vm.summary, routeTitle: "Route") {
                        pdfURL = url; showShare = true
                    }
                } label: {
                    Image(systemName: "square.and.arrow.up")
                }
            }
        }
        .sheet(isPresented: $showShare) {
            if let u = pdfURL { ShareSheet(activityItems: [u]) }
        }
        .navigationDestination(isPresented: Binding(get: { selectedKey != nil }, set: { if !$0 { selectedKey = nil } })) {
            if let key = selectedKey {
                DetailView(key: key)
            }
        }
    }
}

struct SummaryRow: View {
    let item: RouteVM.SummaryItem
    var body: some View {
        HStack {
            Text(item.key).monospacedDigit()
            Spacer()
            VStack(alignment: .trailing) {
                Text("Score \(item.score)")
                Text(String(format: "☔️ %d  ☀️ %.1fh  🌬️ %.0f  🌡️ %.1f°C", item.rainyDays, item.sunHours, item.avgWind, item.avgTemp))
                    .font(.caption)
            }
        }
        .padding(.vertical, 6)
    }
}

struct ShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
