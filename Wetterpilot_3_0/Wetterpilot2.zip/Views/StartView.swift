import SwiftUI

struct StartView: View {
    @EnvironmentObject var vm: RouteVM
    @State private var navKey: String?
    @State private var showPrefs = false
    @State private var showInfo = false
    @State private var isAnalyzing = false
    
    var body: some View {
        NavigationStack {
            Form {
                Section(NSLocalizedString("places_section", comment: "")) {
                    DatePicker(NSLocalizedString("start_date", comment: ""),
                               selection: $vm.startDate, in: vm.minStart...vm.maxStart, displayedComponents: .date)
                    Stepper(value: Binding(get: { vm.durationDays }, set: { vm.updateDuration($0) }), in: 1...10) {
                        Text("\(NSLocalizedString("duration_days", comment: "")) \(vm.durationDays)")
                    }
                    
                    ForEach(0..<vm.durationDays, id: \.self) { i in
                        HStack {
                            Text(dateString(offset: i))
                            TextField(NSLocalizedString("place_placeholder", comment: ""), text: Binding(
                                get: { safe(vm.places, i) },
                                set: { vm.updatePlace(i, $0) }
                            ))
                            .textInputAutocapitalization(.words)
                        }
                    }
                }
                
                Section {
                    Button {
                        Task {
                            isAnalyzing = true
                            await vm.analyze()
                            isAnalyzing = false
                            // navigate to summary
                            navKey = "summary"
                        }
                    } label: {
                        if isAnalyzing {
                            ProgressView()
                        } else {
                            Text(NSLocalizedString("analyze", comment: ""))
                        }
                    }
                    
                    Button(role: .destructive) {
                        vm.resetAll()
                    } label: {
                        Text(NSLocalizedString("new_plan", comment: ""))
                    }
                }
            }
            .navigationTitle(Text("Wetterpilot"))
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Menu {
                        Button { showPrefs = true } label: {
                            Label(NSLocalizedString("menu_preferences", comment: ""), systemImage: "slider.horizontal.3")
                        }
                        Button { showInfo = true } label: {
                            Label(NSLocalizedString("menu_info", comment: ""), systemImage: "info.circle")
                        }
                    } label: {
                        Image(systemName: "ellipsis.circle")
                    }
                }
            }
            .sheet(isPresented: $showPrefs) { PreferenceView() }
            .sheet(isPresented: $showInfo) { InfoView() }
            .navigationDestination(isPresented: Binding(get: { navKey == "summary" }, set: { _ in })) {
                SummaryView()
            }
        }
    }
    
    private func dateString(offset: Int) -> String {
        let d = Calendar.current.date(byAdding: .day, value: offset, to: vm.startDate) ?? vm.startDate
        let df = DateFormatter()
        df.dateStyle = .short
        df.timeStyle = .none
        return df.string(from: d)
    }
    
    private func safe(_ arr: [String], _ i: Int) -> String {
        guard i < arr.count else { return "" }
        return arr[i]
    }
}
