import SwiftUI

struct PreferenceView: View {
    @EnvironmentObject var vm: RouteVM
    
    var body: some View {
        NavigationStack {
            Form {
                Section(NSLocalizedString("prefs_nav_title", comment: "")) {
                    Stepper("Regen: \(vm.weights.rain)", value: $vm.weights.rain, in: 0...3)
                    Stepper("Wind: \(vm.weights.wind)", value: $vm.weights.wind, in: 0...3)
                    Stepper("Hitze: \(vm.weights.heat)", value: $vm.weights.heat, in: 0...3)
                    Stepper("Kälte: \(vm.weights.cold)", value: $vm.weights.cold, in: 0...3)
                    Stepper("Sonne: \(vm.weights.sun)", value: $vm.weights.sun, in: 0...3)
                }
                Section {
                    Button(NSLocalizedString("prefs_reset_defaults", comment: "")) {
                        vm.weights = Weights()
                    }
                }
            }
            .navigationTitle(Text(NSLocalizedString("menu_preferences", comment: "")))
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button(NSLocalizedString("done", comment: "")) { }
                }
            }
        }
    }
}
