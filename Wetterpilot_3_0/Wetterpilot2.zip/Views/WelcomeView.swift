import SwiftUI

struct WelcomeView: View {
    @EnvironmentObject var vm: RouteVM
    @State private var dontShowAgain: Bool = false
    
    var body: some View {
        VStack(spacing: 24) {
            Spacer()
            Text(NSLocalizedString("welcome_title", comment: ""))
                .font(.largeTitle).bold().foregroundColor(.white)
            Text(NSLocalizedString("welcome_subtitle", comment: ""))
                .foregroundColor(.white.opacity(0.9))
            
            VStack(alignment: .leading, spacing: 8) {
                Label(NSLocalizedString("welcome_bullet_1", comment: ""), systemImage: "calendar")
                Label(NSLocalizedString("welcome_bullet_2", comment: ""), systemImage: "map")
                Label(NSLocalizedString("welcome_bullet_3", comment: ""), systemImage: "doc.richtext")
            }
            .foregroundColor(.white)
            
            Toggle(NSLocalizedString("welcome_dontshow", comment: ""), isOn: $dontShowAgain)
                .tint(.white)
                .foregroundColor(.white)
                .padding(.top, 8)
            
            Button(NSLocalizedString("welcome_cta", comment: "")) {
                if dontShowAgain { vm.setHasSeenWelcome() } else { vm.setHasSeenWelcome() }
            }
            .buttonStyle(.borderedProminent)
            .tint(.white)
            .foregroundColor(Color(#colorLiteral(red: 0.04, green: 0.09, blue: 0.23, alpha: 1)))
            Spacer()
        }
        .padding()
        .background(Color("LaunchBackground").ignoresSafeArea())
    }
}
