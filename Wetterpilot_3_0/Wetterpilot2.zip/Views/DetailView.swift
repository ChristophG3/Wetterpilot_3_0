import SwiftUI

struct DetailView: View {
    @EnvironmentObject var vm: RouteVM
    let key: String // yyyy-MM-dd
    
    var body: some View {
        List {
            if let rows = vm.detailsByDate[key] {
                ForEach(rows) { r in
                    HStack {
                        Text(r.dateISO).monospacedDigit().frame(width: 92, alignment: .leading)
                        Text(r.placeName).frame(maxWidth: .infinity, alignment: .leading)
                        Text(r.emoji)
                        VStack(alignment: .trailing) {
                            Text(r.tRange)
                            Text("☔️ \(r.rain)  ☀️ \(r.sun)  🌬️ \(r.wind)")
                                .font(.caption)
                        }
                    }
                    .padding(.vertical, 4)
                }
            } else {
                Text("Keine Details verfügbar")
            }
        }
        .navigationTitle(Text(key))
    }
}
